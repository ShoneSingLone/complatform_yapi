<script lang="ts">
export default async function () {
	return;
}
</script>
