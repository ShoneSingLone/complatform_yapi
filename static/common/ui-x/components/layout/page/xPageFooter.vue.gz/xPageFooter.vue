<style lang="less"></style>
<template>
	<div><slot /></div>
</template>
<script lang="ts">
export default async function () {
	return defineComponent({});
}
</script>
